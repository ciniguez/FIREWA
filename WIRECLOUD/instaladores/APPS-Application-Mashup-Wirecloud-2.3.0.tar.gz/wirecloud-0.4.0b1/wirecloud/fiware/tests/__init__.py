from wirecloud.commons.test import build_selenium_test_cases

build_selenium_test_cases(('wirecloud.fiware.tests.selenium.FiWareSeleniumTestCase',), locals())
