from wirecloud.commons.translator.models import *
