from wirecloud.commons.baseviews.resource import Resource
from wirecloud.commons.baseviews.service import Service
