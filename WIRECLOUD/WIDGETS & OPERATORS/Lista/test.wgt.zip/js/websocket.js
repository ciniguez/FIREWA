var Webskt = function() {
	if (Webskt.singleInstance)
		return Webskt.singleInstance;
	var that = this;
	Webskt.singleInstance = that;

	//that.conn = new WebSocket('ws://localhost:8080/WebSockets/simple');
	that.conn = new WebSocket('ws://158.42.185.198:8080/datawebsocket');
	that.conn.onopen = function() {
		console.log('connected!');
	};
	that.conn.onerror = function(error) {
		console.log("webSocket Error " + error);
	};
	//Acciones a realizar cuando se recibe un mensaje
	that.conn.onmessage = function(e) {
		console.log("Aqui actualización de graficos");
	};
	//Cuando se cierra la conexión se llama a onclose donde e es el motivo del cierre.
	that.conn.onclose = function(e) {
		console.log("webSocket Closed " + e.data);
	};

}; 